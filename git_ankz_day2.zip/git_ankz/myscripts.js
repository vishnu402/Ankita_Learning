function validate() {

    var username = document.getElementById("usrnm").value; // Ankita
    var password = document.getElementById("pswd").value; //Monica

    if (username != "Ankita") {
        alert("invalid user name")
    }

    // select * from tablename where username='username' --> 0 result
    console.log(username, password);
}

function sum() {

    //parsing means convert the data type --- (String---> integer)--->parsing

    var num1 = parseFloat(document.getElementById("number1").value); // 10
    var num2 = parseFloat(document.getElementById("number2").value); //5

    let sum = num1 + num2;
    //document.getElementById("sum").innerHTML=sum;

    document.getElementById("sum1").value = sum;  // = assign not equal guba
    //console.log(sum);
}


function sorting() {

    var a = [6, 2, 1, 7, 8]; //array defination with initialisation

    for (let i = 0; i < 5; i++) {
        console.log(a[i]);
    }

    a.sort(); //sorting of an array
    a.reverse(); /// predefined method  
    console.log(a);

}

// play with some array
// getelementID ---> interview

//var a = [6, 2, 1, 7, 8,8]; //array defination with initialisation
//a.sort(); //sorting of an array

// if condition else, for loop, getelementID, and array,   array each print, duplcate check array.... console

function proof() {

    var p1 = parseFloat(document.getElementById("n1").value);
    var v1 = parseFloat(document.getElementById("n2").value);

    var p2 = parseFloat(document.getElementById("n3").value);
    var v2 = parseFloat(document.getElementById("n4").value);

    let p1v1 = p1 * v1;
    let p2v2 = p2 * v2;

    if (p1v1 != p2v2) {
        alert("not equal")
    }
    else {
        console.log("equal",p1v1);
    }

}